# ResponsiveWeb-TackingPatient-for-Nurse
A website designed for tracking patient status and symptoms can significantly reduce the workload of nurses.
